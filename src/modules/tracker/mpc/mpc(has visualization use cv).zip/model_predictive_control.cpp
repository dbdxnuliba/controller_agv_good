/*************************************************************************
  > File Name: model_predictive_control.cpp
  > Author: TAI Lei
  > Mail: ltai@ust.hk
  > Created Time: Wed Apr 17 11:48:46 2019
 ************************************************************************/

#include<iostream>
#include<iomanip>
#include<limits>
#include<vector>
#include<opencv2/opencv.hpp>
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<sys/time.h>
#include<Eigen/Eigen>
#include<cppad/cppad.hpp>
#include<cppad/ipopt/solve.hpp>
#include"mpc/cubic_spline.h"
#include"motion_model.h"
#include"cpprobotics_types.h"
#include<angles/angles.h>
//车体模型系数矩阵的行数(A,B)
#define NX 4
//窗口大小
#define T 6
//控制周期为0.2s
#define DT 0.1
//车头偏向角以及偏向角变化的阈值
#define MAX_STEER 35.0/180*M_PI
//找最近点时用到,只找10个点够不够?????
#define N_IND_SEARCH 10
//仿真计算次数
#define MAX_TIME 50000
//前后轮的轮距
#define WB 0.64
//最大最小速度,最大加速度
#define MAX_SPEED   1.0
#define MIN_SPEED  -1.0
#define MAX_ACCEL 1.0

using CppAD::AD;
using namespace cpprobotics;
using M_XREF=Eigen::Matrix<float, NX, T>;

//各个时刻状态量的编号
int x_start = 0;
int y_start = x_start + T;
int yaw_start = y_start + T;
int v_start = yaw_start + T;
//各个时刻控制量的编号,a和delta都只有T-1时刻
int delta_start = v_start + T;
int a_start = delta_start + T-1;

cv::Point2i cv_offset(float x, float y, int image_width=2000, int image_height=2000){
  cv::Point2i output;
  output.x = int(x * 20) + 300;
  output.y = image_height - int(y * 20) - image_height/5;
  return output;
}

void update(State& state, float a, float delta){
  if (delta >= MAX_STEER) delta = MAX_STEER;
  if (delta <= - MAX_STEER) delta = - MAX_STEER;

  state.x = state.x + state.v * std::cos(state.yaw) * DT;
  state.y = state.y + state.v * std::sin(state.yaw) * DT;
  state.yaw = state.yaw + state.v / WB * CppAD::tan(delta) * DT;
  state.v = state.v + a * DT;

  if (state.v > MAX_SPEED) state.v = MAX_SPEED;
  if (state.v < MIN_SPEED) state.v = MIN_SPEED;
}

Vec_f calc_speed_profile(Vec_f rx, Vec_f ry, Vec_f ryaw, float target_speed){
  Vec_f speed_profile(ryaw.size(), target_speed);

  float direction = 1.0;
  for(unsigned int i=0; i < ryaw.size()-1; i++){
    float dx = rx[i+1] - rx[i];
    float dy = ry[i+1] - ry[i];
    float move_direction = std::atan2(dy, dx);

    if (dx != 0.0 && dy != 0.0){
      float dangle = std::abs(YAW_P2P(move_direction - ryaw[i]));
      if (dangle >= M_PI/4.0) direction = -1.0;
      else direction = 1.0;
    }

    if (direction != 1.0) speed_profile[i] = -1 * target_speed;
    else speed_profile[i] = target_speed;

  }
  speed_profile[-1] = 0.0;

  return speed_profile;
}

int calc_nearest_index(State state, Vec_f cx, Vec_f cy, Vec_f cyaw, int pind){
  float mind = std::numeric_limits<float>::max();
  float ind = 0;
  for(unsigned int i=pind; i<pind+N_IND_SEARCH; i++){
    float idx = cx[i] - state.x;
    float idy = cy[i] - state.y;
    float d_e = idx*idx + idy*idy;

    if (d_e<mind){
      mind = d_e;
      ind = i;
    }
  }

  return ind;
}

//输出变量为target_ind和xref
void calc_ref_trajectory(State state, Vec_f cx, Vec_f cy, Vec_f cyaw, Vec_f
ck, Vec_f sp, float dl, int& target_ind, M_XREF& xref){

  xref = M_XREF::Zero();
  // dref = Eigen::Matrix<float, 1, T>::Zero();

  int ncourse = cx.size();

  int ind = calc_nearest_index(state, cx, cy, cyaw, target_ind);
  if (target_ind >= ind) ind = target_ind;

  xref(0, 0) = cx[ind];
  xref(1, 0) = cy[ind];
  xref(2, 0) = cyaw[ind];
  xref(3, 0) = sp[ind];

  float travel = 0.0;

  for(int i=0; i<T; i++){
    travel += std::abs(state.v) * DT;
    int dind = (int)std::round(travel/dl);
    // int dind = i;


    if ((ind+dind)<ncourse){
      xref(0, i) = cx[ind + dind];
      xref(1, i) = cy[ind + dind];
      xref(2, i) = cyaw[ind + dind];
      xref(3, i) = sp[ind + dind];
      // dref(0, i) = 0.0;
    }else{
      xref(0, i) = cx[ncourse - 1];
      xref(1, i) = cy[ncourse - 1];
      xref(2, i) = cyaw[ncourse - 1];
      xref(3, i) = sp[ncourse - 1];
      // dref(0, i) = 0.0;
    }
  }

  target_ind = ind;
}

void smooth_yaw(Vec_f& cyaw){
  for(unsigned int i=0; i<cyaw.size()-1; i++){
    float dyaw = cyaw[i+1] - cyaw[i];

    while (dyaw > M_PI/2.0){
      cyaw[i+1] -= M_PI*2.0;
      dyaw = cyaw[i+1] - cyaw[i];
    }
    while (dyaw < -M_PI/2.0){
      cyaw[i+1] += M_PI*2.0;
      dyaw = cyaw[i+1] - cyaw[i];
    }
  }
}


class FG_EVAL{
public:
  // Eigen::VectorXd coeeffs;
  M_XREF traj_ref;

  FG_EVAL(M_XREF traj_ref){
    this->traj_ref = traj_ref;
  }

  typedef CPPAD_TESTVECTOR(AD<double>) ADvector;

  void operator()(ADvector& fg, const ADvector& vars){
    fg[0] = 0;

    for(int i=0; i<T-1; i++){
      fg[0] +=  0.01 * CppAD::pow(vars[a_start+i], 2);
      fg[0] += 0.01 * CppAD::pow(vars[delta_start+i], 2);
    }

    for(int i=0; i<T-2; i++){
      fg[0] += 0.01 * CppAD::pow(vars[a_start+i+1] - vars[a_start+i], 2);
      fg[0] += 1 * CppAD::pow(vars[delta_start+i+1] - vars[delta_start+i], 2);
    }

    // fix the initial state as a constraint
    fg[1 + x_start] = vars[x_start];
    fg[1 + y_start] = vars[y_start];
    fg[1 + yaw_start] = vars[yaw_start];
    fg[1 + v_start] = vars[v_start];
    // The rest of the constraints
    for (int i = 0; i < T - 1; i++) {
      // The state at time t+1 .
      AD<double> x1 = vars[x_start + i + 1];
      AD<double> y1 = vars[y_start + i + 1];
      AD<double> yaw1 = vars[yaw_start + i + 1];
      AD<double> v1 = vars[v_start + i + 1];

      // The state at time t.
      AD<double> x0 = vars[x_start + i];
      AD<double> y0 = vars[y_start + i];
      AD<double> yaw0 = vars[yaw_start + i];
      AD<double> v0 = vars[v_start + i];

      // Only consider the actuation at time t.
      AD<double> delta0 = vars[delta_start + i];
      AD<double> a0 = vars[a_start + i];

      // constraint with the dynamic model
      fg[2 + x_start + i] = x1 - (x0 + v0 * CppAD::cos(yaw0) * DT);
      fg[2 + y_start + i] = y1 - (y0 + v0 * CppAD::sin(yaw0) * DT);
      fg[2 + yaw_start + i] = yaw1 - (yaw0 + v0 * CppAD::tan(delta0) / WB * DT);
      fg[2 + v_start + i] = v1 - (v0 + a0 * DT);
      // cost with the ref traj
      fg[0] += CppAD::pow(traj_ref(0, i+1) - (x0 + v0 * CppAD::cos(yaw0) * DT), 2);
      fg[0] += CppAD::pow(traj_ref(1, i+1) - (y0 + v0 * CppAD::sin(yaw0) * DT), 2);
      fg[0] += 0.5 * CppAD::pow(traj_ref(2, i+1) - (yaw0 + v0 * CppAD::tan(delta0) / WB * DT), 2);
      fg[0] += 0.5 * CppAD::pow(traj_ref(3, i+1) - (v0 + a0 * DT), 2);
    }
  }
};

Vec_f mpc_solve(State x0, M_XREF traj_ref){

  typedef CPPAD_TESTVECTOR(double) Dvector;//vector
  double x = x0.x;
  double y = x0.y;
  double yaw = x0.yaw;
  double v = x0.v;
  //n_vars包括T个时刻状态量和T-1个时刻的控制量
  size_t n_vars = T * 4 + (T - 1) * 2;
  //
  size_t n_constraints = T * 4;
  //todo给定初值,这里除了当前时刻都赋值为0,用上一时刻的求解结果赋值是否可以加速计算
  Dvector vars(n_vars);
  for (int i = 0; i < n_vars; i++){
    vars[i] = 0.0;
  }

  vars[x_start] = x;
  vars[y_start] = y;
  vars[yaw_start] = yaw;
  vars[v_start] = v;

  // Lower and upper limits for x
  Dvector vars_lowerbound(n_vars);
  Dvector vars_upperbound(n_vars);

  // 先将值初始化为一个很大的值,保证不会出现无法求解的情况,然后对需要专门限制的delta,a,v进行限制
  for (auto i = 0; i < n_vars; i++) {
    vars_lowerbound[i] = -10000000.0;
    vars_upperbound[i] = 10000000.0;
  }

  for (auto i = delta_start; i < delta_start+T-1; i++) {
    vars_lowerbound[i] = -MAX_STEER;
    vars_upperbound[i] = MAX_STEER;
  }

  for (auto i = a_start; i < a_start+T-1; i++) {
    vars_lowerbound[i] = -MAX_ACCEL;
    vars_upperbound[i] = MAX_ACCEL;
  }

  for (auto i = v_start; i < v_start+T; i++) {
    vars_lowerbound[i] = MIN_SPEED;
    vars_upperbound[i] = MAX_SPEED;
  }
  //todo为什么赋值为0,是将约束都设置为硬约束?????????????
  Dvector constraints_lowerbound(n_constraints);
  Dvector constraints_upperbound(n_constraints);
  for (auto i = 0; i < n_constraints; i++) {
    constraints_lowerbound[i] = 0;
    constraints_upperbound[i] = 0;
  }
  constraints_lowerbound[x_start] = x;
  constraints_lowerbound[y_start] = y;
  constraints_lowerbound[yaw_start] = yaw;
  constraints_lowerbound[v_start] = v;

  constraints_upperbound[x_start] = x;
  constraints_upperbound[y_start] = y;
  constraints_upperbound[yaw_start] = yaw;
  constraints_upperbound[v_start] = v;
  //todo包含了cost函数和线性模型的矩阵参数??????????
  FG_EVAL fg_eval(traj_ref);

  // options for IPOPT solver
  std::string options;
  // Uncomment this if you'd like more print information
  options += "Integer print_level  0\n";
  //注意：将sparse设置为true可使求解器利用稀疏例程，这会使计算更加快速。
  //如果您可以取消注释其中之一，并查看是否有所不同，但是如果您都取消注释，
  //则计算时间应增加几个数量级。
  //options += "Sparse  true        forward\n";
  options += "Sparse  true        reverse\n";
  options += "Integer max_iter      50\n";
  options += "Numeric tol          1e-6\n";
  // NOTE: Currently the solver has a maximum time limit of 0.05 seconds.
    // Change this as you see fit.
  options += "Numeric max_cpu_time          0.5\n";

  // place to return solution
  CppAD::ipopt::solve_result<Dvector> solution;

  // solve the problem
  CppAD::ipopt::solve<Dvector, FG_EVAL>(
      options, vars, vars_lowerbound, vars_upperbound, constraints_lowerbound,
      constraints_upperbound, fg_eval, solution);

  bool ok = true;
  ok &= solution.status == CppAD::ipopt::solve_result<Dvector>::success;

  Vec_f result;
  for (auto i =0 ; i < n_vars; i++) {
    result.push_back((float)solution.x[i]);
  }
  return result;
}

void mpc_simulation(Vec_f cx, Vec_f cy, Vec_f cyaw, Vec_f ck, Vec_f speed_profile, Poi_f goal){
  State state(cx[0], cy[0], cyaw[0], speed_profile[0]);
  //角度正规化
  if ((state.yaw - cyaw[0]) >= M_PI) state.yaw -= M_PI * 2.0;
  else if ((state.yaw - cyaw[0]) <= -1.0*M_PI) state.yaw += M_PI * 2.0;

  float goal_dis = 0.05;
  int iter_count = 0;

  int target_ind = 0;
  //获取最近的点号
  calc_nearest_index(state, cx, cy, cyaw, target_ind);
  //点之间角度差正规化
  smooth_yaw(cyaw);

  M_XREF xref;

  while (MAX_TIME >= iter_count){
    //输出目标点编号以及T个时刻的预测状态
    calc_ref_trajectory(state, cx, cy, cyaw, ck, speed_profile, 1.0, target_ind, xref);
    //计算mpc
    Vec_f output = mpc_solve(state, xref);
    //根据求解器输出的结果进行状态量的更新
    update(state, output[a_start], output[delta_start]);
    //获取当前时刻车轮转角
    float steer = output[delta_start];
    //计算是否到达目标点
    float dx = state.x - goal[0];
    float dy = state.y - goal[1];
    if (std::sqrt(dx*dx + dy*dy) <= goal_dis) {
      std::cout<<("Goal")<<std::endl;
      break;
    }
#if 0
    // 参数1为窗口名称,参数2为窗口的标识
    //WINDOW_AUTOSIZE 窗口大小自动适应图片大小，并且不可手动更改
    //WINDOW_NORMAL 用户可以改变这个窗口大小
    //WINDOW_OPENGL 窗口创建的时候会支持OpenGL
    cv::namedWindow("mpc", cv::WINDOW_NORMAL);
    int count = 0;
    Vec_f x_h;
    Vec_f y_h;

    x_h.push_back(state.x);
    y_h.push_back(state.y);

    // cv::Mat m(int rows, int cols, int type, const Scalar& s)
    //cv::Scalar(255, 255, 255)颜色赋值
    //定义出图像的背景颜色
    cv::Mat bg(600, 1066, CV_8UC3, cv::Scalar(238, 232, 170));
    //第一个参数img：要划的线所在的图像;
    //第二个参数pt1：直线起点
    //第三个参数pt2：直线终点
    //第四个参数color：直线的颜色 e.g:Scalor(0,0,255)
    //第五个参数thickness=1：线条粗细
    //第六个参数line_type=8,
    //第七个参数：坐标点的小数点位数
    for(unsigned int i=1; i<cx.size(); i++){
      cv::line(
        bg,
        cv_offset(cx[i-1], cy[i-1], bg.cols, bg.rows),
        cv_offset(cx[i], cy[i], bg.cols, bg.rows),
        cv::Scalar(0, 0, 0),
        5);
    }
    //第一个参数img：要划的线所在的图像;
    //第二个参数为圆心坐标
    //第三个参数为圆的半径
    //第四个参数为颜色
    //第五个参数为设置圆线条的粗细，值越大则线条越粗，为负数则是填充效果
    for(unsigned int k=0; k<x_h.size(); k++){
      cv::circle(
        bg,
        cv_offset(x_h[k], y_h[k], bg.cols, bg.rows),
        3, cv::Scalar(255, 0, 0), -1);
    }


    cv::line(
      bg,
      cv_offset(state.x, state.y, bg.cols, bg.rows),
      cv_offset(state.x + std::cos(state.yaw)*WB*2, state.y + std::sin(state.yaw)*WB*2, bg.cols, bg.rows),
      cv::Scalar(255,0,255),
      5);

    cv::line(
      bg,
      cv_offset(state.x + std::cos(state.yaw)*0.1,
                state.y + std::sin(state.yaw)*0.1,
                bg.cols, bg.rows),
      cv_offset(state.x - std::cos(state.yaw)*0.1,
                state.y - std::sin(state.yaw)*0.1,
                bg.cols, bg.rows),
      cv::Scalar(255,0,127),
      10);

    cv::line(
      bg,
      cv_offset(state.x + std::cos(state.yaw)*WB*2 + std::cos(state.yaw+steer)*0.1,
                state.y + std::sin(state.yaw)*WB*2 + std::sin(state.yaw+steer)*0.1,
                bg.cols, bg.rows),
      cv_offset(state.x + std::cos(state.yaw)*WB*2 - std::cos(state.yaw+steer)*0.1,
                state.y + std::sin(state.yaw)*WB*2 - std::sin(state.yaw+steer)*0.1,
                bg.cols, bg.rows),
      cv::Scalar(255,0,127),
      10);
    //cv::drawMarker
    //第一个参数为图像
    //第二个参数为标记位置
    //第三个参数为颜色
    //第四个参数为标记类型
    //第五个参数为标记尺寸
    //第六个参数为线粗细
    for(unsigned int k=0; k<xref.cols(); k++){
      cv::drawMarker(
        bg,
        cv_offset(xref(0, k), xref(1, k), bg.cols, bg.rows),
        cv::Scalar(0, 255, 255),
        cv::MARKER_CROSS,
        20, 3);
    }
    //imshow负责的就是将图片显示在窗口中
    cv::imshow("mpc", bg);
    //延时5毫秒,如果是0表示无限等待
    cv::waitKey(5);
#endif
    iter_count++;
  }
}

int main(){

  //输入预设的坐标点
  Vec_f wx({0.0, 12.0, 25.0,  10.0,   15.0,  7.0,  -2.0});
  Vec_f wy({0.0,  0.0,  10.0,  13.0,   6.0,  10.0,  -4.0});
  //生成二次样条曲线
  Spline2D csp_obj(wx, wy);
  Vec_f r_x;
  Vec_f r_y;
  Vec_f ryaw;//每个点处切线
  Vec_f rcurvature;//曲率
  Vec_f rs;//每段路径的长度
  for(float i=0; i<csp_obj.s.back(); i+=1.0){
    std::array<float, 2> point_ = csp_obj.calc_postion(i);
    r_x.push_back(point_[0]);
    r_y.push_back(point_[1]);
    ryaw.push_back(csp_obj.calc_yaw(i));
    rcurvature.push_back(csp_obj.calc_curvature(i));
    rs.push_back(i);
  }

  float target_speed = 1.0;
  Vec_f speed_profile = calc_speed_profile(r_x, r_y, ryaw, target_speed);

  mpc_simulation(r_x, r_y, ryaw, rcurvature, speed_profile, {{wx.back(), wy.back()}});
}
