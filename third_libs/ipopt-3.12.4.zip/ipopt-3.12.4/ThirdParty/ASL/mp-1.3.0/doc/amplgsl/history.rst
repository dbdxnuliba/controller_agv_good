History
=======

* *AMPL bindings for the GNU Scientific Library* (2012). Victor Zverovich.

* *GNU Scientiﬁc Library* Reference Manual (2011). Mark Galassi, Jim Davies,
  James Theiler, Brian Gough, Gerard Jungman, Patrick Alken, Michael Booth,
  Fabrice Rossi.
