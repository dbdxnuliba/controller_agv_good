AMPL Bindings for the GNU Scientific Library
============================================

.. toctree::
   :maxdepth: 2

   front-matter
   intro
   elementary
   special
   rng
   randist
   freedoc
   gpl
   fdl
   history
 
