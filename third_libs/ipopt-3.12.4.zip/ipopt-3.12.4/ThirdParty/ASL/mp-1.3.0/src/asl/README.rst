This directory contains a C++ interface to the AMPL Solver Library.

The solvers directory is based on the AMPL material available from
http://ampl.com/netlib/ which is a more up-to-date version of the
`AMPL Netlib repository <http://netlib.org/ampl>`__.
