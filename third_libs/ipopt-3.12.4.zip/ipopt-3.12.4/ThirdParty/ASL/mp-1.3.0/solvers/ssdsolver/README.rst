A solver for problems with second-order stochastic dominance constraints.
